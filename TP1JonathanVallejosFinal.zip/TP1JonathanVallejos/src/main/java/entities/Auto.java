package entities;

import lombok.Getter;

@Getter
public abstract class  Auto {
    public String marca;
    public String modelo;
    public String color;
    public double precio;
    public Radio radio;

    public Auto(String marca, String modelo, String color, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Auto [marca=" + marca + ", modelo=" + modelo + ", color=" + color + ", precio=" + precio + ", radio="
                + radio + "]";
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void setRadio(String marcaRadio, String potencia) {
        radio = new Radio(marcaRadio, potencia);
    }

    




    





}

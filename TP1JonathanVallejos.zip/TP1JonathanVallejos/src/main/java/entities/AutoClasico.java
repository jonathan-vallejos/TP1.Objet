package entities;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class AutoClasico extends Auto {
    
    public AutoClasico(String marca, String modelo, String color, double precio, String marcaRadio, String potenciaRadio) {
        super(marca, modelo, color, precio);
        super.radio = new Radio(marcaRadio, potenciaRadio);
    }
    
    
    
}

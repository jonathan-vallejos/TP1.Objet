package entities;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AutoNuevo extends Auto {

    public AutoNuevo(String marca, String modelo, String color, double precio, String marcaRadio, String potenciaRadio) {
        super(marca, modelo, color, precio);
        super.radio = new Radio(marcaRadio, potenciaRadio);
    }

    public void setRadio(String string, String string2) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setRadio'");
    }



}

package test;

import entities.AutoClasico;
import entities.AutoNuevo;
import entities.Colectivo;

public class TestAutoRadio {
    public static void main(String[] args) {
        
        //Probar AutoNuevo
        System.out.println("--- auto 1 ---");
        AutoNuevo auto1 = new AutoNuevo("Ferrari", "Sainz", "Rojo", 12339, "Sony", "50w");
        System.out.println(auto1);

        //Probar AutoClasico
        System.out.println("--- auto2 ---");
        AutoClasico auto2 = new AutoClasico("Mercedes Benz", "Hamillton", "Verde", 12098, "Sanyo", "50w");
        System.out.println(auto2);
        
        //Probar Colectivo
        System.out.println("--- auto3 ---");
        Colectivo auto3 = new Colectivo("Mercedes Benz", "Bus", "Amarillo", 120982, "Sony", "8888w");
        System.out.println(auto3);


    }
}

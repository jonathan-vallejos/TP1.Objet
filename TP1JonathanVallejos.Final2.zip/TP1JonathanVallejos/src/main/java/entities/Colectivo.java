package entities;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Colectivo extends Vehiculo{
    
    public Colectivo(String marca, String modelo, String color) {
        super(marca, modelo, color);
    }
    
}

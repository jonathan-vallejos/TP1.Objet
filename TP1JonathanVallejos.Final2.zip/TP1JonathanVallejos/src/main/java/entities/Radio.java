package entities;

import lombok.Getter;

@Getter
public class Radio {
    String marca;
    String potencia;
    
    public Radio(String marca, String potencia) {
        this.marca = marca;
        this.potencia = potencia;
    }

    @Override
    public String toString() {
        return "Radio [marca=" + marca + ", potencia=" + potencia + "]";
    }

}

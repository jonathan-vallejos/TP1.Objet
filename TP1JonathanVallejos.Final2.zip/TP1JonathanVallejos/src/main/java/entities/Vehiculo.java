package entities;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public abstract class  Vehiculo {
    public String marca;
    public String modelo;
    public String color;
    public double precio;
    public Radio radio;


    public Vehiculo(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }


    public Vehiculo(String marca, String modelo, String color, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
    }


    @Override
    public String toString() {
        return "Vehiculo [marca=" + marca + ", modelo=" + modelo + ", color=" + color + ", precio=" + precio
                + ", radio=" + radio + "]";
    }


    public void setPrecio(double precio) {
        this.precio = precio;
        
    }


    public void setRadio(String marcaRadio, String potencia) {
        radio = new Radio(marcaRadio, potencia);
    }

}

package entities;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class AutoClasico extends Vehiculo {
    
    public AutoClasico(String marca, String modelo, String color) {
        super(marca, modelo, color);
    }
    
}

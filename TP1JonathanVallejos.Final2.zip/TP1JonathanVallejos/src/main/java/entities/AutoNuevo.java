package entities;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AutoNuevo extends Vehiculo {

    String marcaRadio;
    String potenciaRadio;


    public AutoNuevo(String marca, String modelo, String color, String marcaRadio, String potenciaRadio) {
        super(marca, modelo, color);
        super.radio = new Radio(marcaRadio, potenciaRadio);
    }

}

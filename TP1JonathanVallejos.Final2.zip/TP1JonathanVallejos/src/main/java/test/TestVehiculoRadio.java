package test;
import entities.AutoClasico;
import entities.AutoNuevo;
import entities.Colectivo;

public class TestVehiculoRadio {
    public static void main(String[] args) {
        
        //Probar AutoNuevo
        System.out.println("--- auto 1 ---");

        AutoNuevo auto1 = new AutoNuevo("Ferrari", "Sainz", "Rojo", "Panasonic", "30w");
        System.out.println(auto1);
        
        auto1.setPrecio(12.000);
        System.out.println(auto1);
        
        auto1.setRadio("Sony", "80w");
        System.out.println(auto1);
        

        //Probar AutoClasico
        System.out.println("--- auto2 ---");

        AutoClasico auto2 = new AutoClasico("Mercedes Benz", "Hamillton", "Verde");
        System.out.println(auto2);

        auto2.setPrecio(20.000);
        System.out.println(auto2);
        
        auto2.setRadio("Pionner", "100w");
        System.out.println(auto2);
        


        //Probar Colectivo
        System.out.println("--- auto3 ---");

        Colectivo auto3 = new Colectivo("Mercedes Benz", "Z201", "Verde");
        System.out.println(auto3);

        auto3.setPrecio(150.000);
        System.out.println(auto3);

        auto3.setRadio("Thonet & Vander", "95W");
        System.out.println(auto3);

    }

}

package Tp.JonathanVallejos.TP1JonathanVallejos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tp1JonathanVallejosApplicationTests {

	@Test
	void contextLoads() {
	}

}

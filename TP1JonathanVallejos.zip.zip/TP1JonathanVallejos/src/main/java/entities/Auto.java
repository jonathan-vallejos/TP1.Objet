package entities;

public abstract class  Auto {
    public String marca;
    public String modelo;
    public String color;
    public double precio;
    public Radio radio;

    public Auto(String marca, String modelo, String color) {
        
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }

    

    public Auto(String marca, String modelo, String color, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
    }


    public Auto(String marca, String modelo, String color, double precio, Radio radio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
        this.radio = radio;
    }

    


    @Override
    public String toString() {
        return "Auto [marca=" + marca + ", modelo=" + modelo + ", color=" + color + ", precio=" + precio + ", radio="
                + radio + "]";
    }



    public void setMarca(String marca) {
        this.marca = marca;
    }



    public void setModelo(String modelo) {
        this.modelo = modelo;
    }



    public void setColor(String color) {
        this.color = color;
    }



    public String getMarca() {
        return marca;
    }



    public String getModelo() {
        return modelo;
    }



    public String getColor() {
        return color;
    }



    public double getPrecio() {
        return precio;
    }



    public Radio getRadio(String string, String string2) {
        return radio;
    }



    public void setPrecio(double precio) {
        this.precio = precio;
    }



    public void setRadio(Radio radio) {
        this.radio = radio;
    }

    




    





}

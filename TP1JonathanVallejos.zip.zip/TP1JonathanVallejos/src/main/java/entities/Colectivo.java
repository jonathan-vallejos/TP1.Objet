package entities;

public class Colectivo extends Auto{

    public Colectivo(String marca, String modelo, String color, double precio, String marcaRadio, String potenciaRadio) {
        super(marca, modelo, color, precio);
        super.radio = new Radio(marcaRadio, potenciaRadio);
    }

    
    

    

}
